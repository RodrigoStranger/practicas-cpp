#ifndef LIBRERIAS_H
#define LIBRERIAS_H

#include <cstdlib>
#include <ctime>
#include <cctype>
#include <iostream>
#include <vector>
#include <string>

using namespace std;

#endif